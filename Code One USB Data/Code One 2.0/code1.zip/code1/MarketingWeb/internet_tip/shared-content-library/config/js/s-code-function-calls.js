logScatalystValuesToFirebugConsole("Page Load");
